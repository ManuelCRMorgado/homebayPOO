package pt.iade.homebay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HomebayApplicationTests {

	@Test
	void contextLoads() {
	}

}
