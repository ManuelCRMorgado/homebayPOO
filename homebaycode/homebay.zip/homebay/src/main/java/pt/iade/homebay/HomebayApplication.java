package pt.iade.homebay;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HomebayApplication {

	public static void main(String[] args) {
		SpringApplication.run(HomebayApplication.class, args);
	}

}
